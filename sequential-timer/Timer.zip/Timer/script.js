let timers = [];
let currentTimer = null;
let isRunning = false;

function addTimer() {
    const minutes = parseInt(document.getElementById('minutes').value) || 0;
    const seconds = parseInt(document.getElementById('seconds').value) || 0;
    const totalSeconds = minutes * 60 + seconds;
    
    if (totalSeconds > 0) {
        timers.push(totalSeconds);
        updateTimerDisplay();
        clearInputs();
    }
}

function updateTimerDisplay() {
    const timerList = document.getElementById('timerList');
    timerList.innerHTML = '';
    
    timers.forEach((time, index) => {
        const minutes = Math.floor(time / 60);
        const seconds = time % 60;
        const timerDiv = document.createElement('div');
        timerDiv.className = 'timer-item';
        timerDiv.innerHTML = `
            <span>計時器 ${index + 1}: ${minutes}分 ${seconds}秒</span>
            <button onclick="removeTimer(${index})">刪除</button>
        `;
        timerList.appendChild(timerDiv);
    });
}

function removeTimer(index) {
    timers.splice(index, 1);
    updateTimerDisplay();
}

function startTimers() {
    if (!isRunning && timers.length > 0) {
        isRunning = true;
        currentTimer = 0;
        runTimer();
    }
}

function runTimer() {
    if (currentTimer >= timers.length) {
        isRunning = false;
        return;
    }

    let timeLeft = timers[currentTimer];
    const timerInterval = setInterval(() => {
        timeLeft--;
        timers[currentTimer] = timeLeft;
        updateTimerDisplay();

        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            playAlarm();
            currentTimer++;
            setTimeout(() => {
                if (currentTimer < timers.length) {
                    runTimer();
                } else {
                    isRunning = false;
                }
            }, 4000); // 等待鬧鈴播放完畢
        }
    }, 1000);
}

function playAlarm() {
    const alarm = document.getElementById('alarmSound');
    alarm.play();
    setTimeout(() => {
        alarm.play();
    }, 2000); // 2秒後播放第二次
}

function resetTimers() {
    timers = [];
    isRunning = false;
    currentTimer = null;
    updateTimerDisplay();
}

function clearInputs() {
    document.getElementById('minutes').value = '';
    document.getElementById('seconds').value = '';
}
