// This plugin will open a window to prompt the user to enter a number, and
// it will then create that many rectangles on the screen.

// This file holds the main code for plugins. Code in this file has access to
// the *figma document* via the figma global object.
// You can access browser APIs in the <script> tag inside "ui.html" which has a
// full browser environment (See https://www.figma.com/plugin-docs/how-plugins-run).

// This shows the HTML page in "ui.html".
figma.showUI(__html__, { width: 300, height: 450 });

// Calls to "parent.postMessage" from within the HTML page will trigger this
// callback. The callback will be passed the "pluginMessage" property of the
// posted message.
figma.ui.onmessage = async (msg) => {
  if (msg.type === 'create-gif') {
    const selection = figma.currentPage.selection;
    
    if (selection.length === 0 || selection[0].type !== 'FRAME') {
      figma.notify('請選擇一個Frame');
      return;
    }

    const frame = selection[0] as FrameNode;
    
    try {
      // 獲取 Frame 中的所有子元素
      const layers = frame.children;
      
      // 創建一個數組來存儲每個層的圖像數據
      const imageDataArray = [];
      
      // 遍歷每個層並導出為圖像
      for (const layer of layers) {
        if ('visible' in layer && layer.visible) {
          const imageData = await layer.exportAsync({
            format: 'PNG',
            constraint: { type: 'SCALE', value: 1 }
          });
          imageDataArray.push(imageData);
        }
      }

      // 將圖像數據發送到 UI 以生成 GIF
      figma.ui.postMessage({
        type: 'generate-gif',
        imageDataArray: imageDataArray,
        background: msg.background,
        speed: msg.speed
      });

      figma.notify('正在生成 GIF，請稍候...');
    } catch (error) {
      figma.notify('GIF 生成失敗: ' + error.message);
    }
  }
};

// Make sure to close the plugin when you're done. Otherwise the plugin will
// keep running, which shows the cancel button at the bottom of the screen.
figma.closePlugin();
