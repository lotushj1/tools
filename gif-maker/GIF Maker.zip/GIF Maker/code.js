figma.showUI(__html__, { width: 300, height: 450 });

// 主函數
async function convertFramesToGIF(speed, loopCount) {
  const selection = figma.currentPage.selection;
  if (selection.length === 0) {
    figma.notify('請選擇至少一個 Frame');
    return;
  }

  const frames = selection.filter(node => node.type === 'FRAME');
  if (frames.length === 0) {
    figma.notify('請選擇至少一個 Frame');
    return;
  }

  const images = [];
  for (const frame of frames) {
    const imageUint8Array = await frame.exportAsync({
      format: 'PNG',
      constraint: { type: 'SCALE', value: 1 }
    });
    images.push(imageUint8Array);
  }

  figma.ui.postMessage({
    type: 'generate-gif',
    images: images,
    speed: speed,
    loopCount: loopCount,
    width: frames[0].width,
    height: frames[0].height
  });
}

figma.ui.onmessage = async (msg) => {
  if (msg.type === 'create-gif') {
    await convertFramesToGIF(msg.speed, msg.loopCount);
  } else if (msg.type === 'close') {
    figma.closePlugin();
  }
};